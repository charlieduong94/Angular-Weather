// controller for current weather
angular.module('SharedElements').service("UnitToggleService", function(){
  var self = this;
  self.unit = "fahrenheit";
  
});
