Angular Weather

Simple weather extension that anyone can use.